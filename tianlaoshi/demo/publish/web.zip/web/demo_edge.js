(function (compId) {
    var _ = null, y = true, n = false, x12 = 'break-word', x86 = '403px', e20 = '${tit}', x59 = 'rects', x40 = '900', x78 = '512', x25 = '1154px', e98 = '${TEXT_GETKNOW}', x23 = '32px', x29 = 'RectangleCopy', x34 = 'RectangleCopy4', x75 = 'TEXT_WELCOME', x28 = 'rgba(255,255,255,1.00)', x37 = '630px', x39 = 'RectangleCopy2', i = 'none', x10 = '42', x3 = '6.0.0.400', e96 = '${TEXT_WELCOME}', lf = 'left', e99 = '${TEXT_URL}', e97 = '${rects}', x73 = '352px', x50 = '512px', e100 = '${qrcode}', x76 = '86px', e95 = '${TEXT_ENTER}', e19 = '${banner}', e17 = '${rigthDot}', x89 = '305px', e21 = '${leftDot}', x27 = 'auto', e94 = '${TEXT_SCAN}', x93 = '586px', x92 = '1105px', tp = 'top', x90 = 'qrcode', xc = 'rgba(0,0,0,1)', x54 = '100', x51 = 'TextCopy3', x88 = '303px', zy = 'scaleY', x13 = 'nowrap', e16 = '${des}', x61 = '-29px', x4 = 'rgba(0,0,0,0)', x22 = 'Rectangle', x87 = '73px', g = 'image', x85 = 'TEXT_SCAN', x84 = '320', x83 = '58px', x82 = 'TEXT_ENTER', x45 = 'TextCopy', x63 = '644', x24 = '30px', x58 = '0.91', x = 'text', x80 = '157px', x30 = '1px', x60 = '-55px', x74 = '334', m = 'rect', x31 = '0px', x77 = '240px', x71 = '0.5', x70 = 'TEXT_URL', x65 = '0', x68 = '590', x67 = '463px', x66 = '278px', x69 = '74', x64 = '1', p = 'px', o = 'opacity', x62 = '1214', x32 = '14px', x72 = '98px', x44 = '74px', x33 = '644px', x55 = 'TextCopy4', x79 = 'TEXT_GETKNOW', x1 = '6.0.0', x11 = 'Arial, Helvetica, sans-serif', x15 = 'rgba(241,239,239,1.00)', l = 'normal', x2 = '5.0.0', zx = 'scaleX', x48 = 'TextCopy2', x47 = '384px', x41 = 'Text', x36 = 'RectangleCopy3', x81 = '384', x26 = '583px', x53 = '334px', x57 = '590px', e18 = '${person}', x43 = '320px', x38 = '1214px', x35 = '1200px';
    var g7 = 'leftDot.png', g5 = 'Pasted-1.jpg', g91 = 'Pasted.png', g6 = 'Pasted-4.jpg', g8 = 'rigthDot.png';
    var s52 = "<p style=\"margin: 0px;\">"+document.getElementById("text_welcome").innerHTML+"</p>", 
    s14 = "<p style=\"margin: 0px;\">​"+document.getElementById("text_tit").innerHTML+"</p>",
     s56 = "<p style=\"margin: 0px;\"><span style=\"font-size: 38px;\">"+document.getElementById("text_url").innerHTML+"</span></p>", 
     s49 = "<p style=\"margin: 0px;\">"+document.getElementById("text_getKnow").innerHTML+"</p>",
      s46 = "<p style=\"margin: 0px;\">"+document.getElementById("text_enter").innerHTML+"</p>", 
      s42 = "<p style=\"margin: 0px;\">​"+document.getElementById("text_scan").innerHTML+"</p>", 
      s9 = "<p style=\"margin: 0px;\">​"+document.getElementById("text_des").innerHTML+"</p>";
    var im = 'images/', aud = 'media/', vid = 'media/', js = 'js/', fonts = {}, opts = {
        'gAudioPreloadPreference': 'auto',
        'gVideoPreloadPreference': 'auto'
    }, resources = [], scripts = [], symbols = {
        "stage": {
            v: x1,
            mv: x2,
            b: x3,
            stf: i,
            cg: i,
            rI: n,
            cn: {
                dom: [{
                    id: 'person',
                    t: g,
                    r: ['396px', '-64px', '876px', '876px', 'auto', 'auto'],
                    o: '0',
                    f: [x4, document.getElementById("url_person").src, '0px', '0px'],
                    tf: [[], [], [], ['0.79', '0.79']]
                }, {
                    id: 'banner',
                    symbolName: 'banner',
                    t: m,
                    r: ['-144px', '170px', '1105', '586', 'auto', 'auto']
                }, {
                    id: 'logo',
                    t: g,
                    r: ['61px', '43px', '236px', '76px', 'auto', 'auto'],
                    f: [x4, document.getElementById("url_logo").src , '0px', '0px']
                }, {
                    id: 'leftDot',
                    t: g,
                    r: ['-127px', '246px', '39px', '36px', 'auto', 'auto'],
                    f: [x4, document.getElementById("url_leftDot").src, '0px', '0px']
                }, {
                    id: 'rigthDot',
                    t: g,
                    r: ['720px', '493px', '39px', '35px', 'auto', 'auto'],
                    o: '0',
                    f: [x4, document.getElementById("url_rigthDot").src, '0px', '0px']
                }, {
                    id: 'des',
                    t: x,
                    r: ['123px', '253px', 'auto', 'auto', 'auto', 'auto'],
                    o: '0',
                    text: s9,
                    n: [x11, [x10, p], xc, l, i, "", x12, x13]
                }, {
                    id: 'tit',
                    t: x,
                    r: ['123px', '201px', 'auto', 'auto', 'auto', 'auto'],
                    o: '0',
                    text: s14,
                    n: [x11, [x10, p], xc, l, i, "", x12, x13]
                }],
                style: {
                    '${Stage}': {
                        isStage: true,
                        r: ['null', 'null', '1280px', '720px', 'auto', 'auto'],
                        overflow: 'hidden',
                        f: [x15]
                    }
                }
            },
            tt: {
                d: 3382.36328125,
                a: y,
                data: [["eid87", lf, 3000, 382, "easeOutBack", e16, '507px', '123px'], ["eid77", o, 2759, 241, "linear", e17, '0.000000', '1'], ["eid70", zx, 2000, 750, "easeInOutCubic", e18, '1', '0.79'], ["eid59", zx, 2000, 500, "easeInOutCubic", e19, '1', '0.52'], ["eid82", lf, 3000, 382, "easeInOutCubic", e20, '507px', '123px'], ["eid81", o, 3000, 382, "linear", e20, '0', '1'], ["eid86", o, 3000, 382, "linear", e16, '0', '1'], ["eid74", lf, 2750, 250, "linear", e21, '-127px', '62px'], ["eid65", lf, 2000, 0, "easeInOutCubic", e18, '396px', '396px'], ["eid69", o, 2000, 750, "easeInOutCubic", e18, '0', '1'], ["eid61", lf, 2000, 500, "easeInOutCubic", e19, '85px', '-144px'], ["eid71", zy, 2000, 750, "easeInOutCubic", e18, '1', '0.79'], ["eid72", tp, 2000, 750, "easeInOutCubic", e18, '-156px', '-64px'], ["eid62", tp, 2000, 500, "easeInOutCubic", e19, '66px', '170px'], ["eid60", zy, 2000, 500, "easeInOutCubic", e19, '1', '0.52']]
            }
        },
        "rects": {
            v: x1,
            mv: x2,
            b: x3,
            stf: i,
            cg: i,
            rI: n,
            cn: {
                dom: [{t: m, id: x22, s: [0, xc, i], r: [x23, x24, x25, x26, x27, x27], f: [x28]}, {
                    t: m,
                    id: x29,
                    s: [0, xc, i],
                    r: [x30, x31, x32, x33, x27, x27],
                    f: [x28]
                }, {t: m, id: x34, s: [0, xc, i], r: [x35, x31, x32, x33, x27, x27], f: [x28]}, {
                    t: m,
                    id: x36,
                    s: [0, xc, i],
                    r: [x31, x37, x38, x32, x27, x27],
                    f: [x28]
                }, {t: m, id: x39, s: [0, xc, i], r: [x31, x31, x38, x32, x27, x27], f: [x28]}],
                style: {'${symbolSelector}': {r: [_, _, x38, x33]}}
            },
            tt: {d: 0, a: y, data: []}
        },
        "TEXT_SCAN": {
            v: x1,
            mv: x2,
            b: x3,
            stf: i,
            cg: i,
            rI: n,
            cn: {
                dom: [{
                    n: [x11, [64, p], xc, x40, i, '', x12, x13],
                    id: x41,
                    text: s42,
                    t: x,
                    r: [x31, x31, x27, x27, x27, x27]
                }], style: {'${symbolSelector}': {r: [_, _, x43, x44]}}
            },
            tt: {d: 0, a: y, data: []}
        },
        "TEXT_ENTER": {
            v: x1,
            mv: x2,
            b: x3,
            stf: i,
            cg: i,
            rI: n,
            cn: {
                dom: [{
                    n: [x11, [64, p], xc, x40, i, '', x12, x13],
                    id: x45,
                    text: s46,
                    t: x,
                    r: [x31, x31, x27, x27, x27, x27]
                }], style: {'${symbolSelector}': {r: [_, _, x47, x44]}}
            },
            tt: {d: 0, a: y, data: []}
        },
        "TEXT_GETKNOW": {
            v: x1,
            mv: x2,
            b: x3,
            stf: i,
            cg: i,
            rI: n,
            cn: {
                dom: [{
                    n: [x11, [64, p], xc, x40, i, '', x12, x13],
                    id: x48,
                    text: s49,
                    t: x,
                    r: [x31, x31, x27, x27, x27, x27]
                }], style: {'${symbolSelector}': {r: [_, _, x50, x44]}}
            },
            tt: {d: 0, a: y, data: []}
        },
        "TEXT_WELCOME": {
            v: x1,
            mv: x2,
            b: x3,
            stf: i,
            cg: i,
            rI: n,
            cn: {
                dom: [{
                    n: [x11, [64, p], xc, x40, i, '', x12, x13],
                    id: x51,
                    text: s52,
                    t: x,
                    r: [x31, x31, x27, x27, x27, x27]
                }], style: {'${symbolSelector}': {r: [_, _, x53, x44]}}
            },
            tt: {d: 0, a: y, data: []}
        },
        "TEXT_URL": {
            v: x1,
            mv: x2,
            b: x3,
            stf: i,
            cg: i,
            rI: n,
            cn: {
                dom: [{
                    n: [x11, [64, p], xc, x54, i, '', x12, x13],
                    id: x55,
                    text: s56,
                    t: x,
                    r: [x31, x31, x27, x27, x27, x27]
                }], style: {'${symbolSelector}': {r: [_, _, x57, x44]}}
            },
            tt: {d: 0, a: y, data: []}
        },
        "banner": {
            v: x1,
            mv: x2,
            b: x3,
            stf: i,
            cg: i,
            rI: n,
            cn: {
                dom: [{
                    tf: [[], [], [], [x58, x58]],
                    id: x59,
                    sN: x59,
                    r: [x60, x61, x62, x63, x27, x27],
                    t: m
                }, {
                    tf: [[], [], [], [x64, x65]],
                    r: [x66, x67, x68, x69, x27, x27],
                    id: x70,
                    sN: x70,
                    o: x65,
                    t: m
                }, {
                    tf: [[], [], [], [x71, x71]],
                    r: [x72, x73, x74, x69, x27, x27],
                    id: x75,
                    sN: x75,
                    o: x65,
                    t: m
                }, {
                    tf: [[], [], [], [x64, x65]],
                    r: [x76, x77, x78, x69, x27, x27],
                    id: x79,
                    sN: x79,
                    o: x65,
                    t: m
                }, {
                    tf: [[], [], [], [x64, x65]],
                    r: [x76, x80, x81, x69, x27, x27],
                    id: x82,
                    sN: x82,
                    o: x65,
                    t: m
                }, {
                    tf: [[], [], [], [x64, x65]],
                    r: [x76, x83, x84, x69, x27, x27],
                    id: x85,
                    sN: x85,
                    o: x65,
                    t: m
                }, {r: [x86, x87, x88, x89, x27, x27], id: x90, t: g, f: [x4, document.getElementById("url_qrcode").src, x31, x31]}],
                style: {'${symbolSelector}': {r: [_, _, x92, x93]}}
            },
            tt: {
                d: 2000,
                a: y,
                data: [["eid3", o, 250, 0, "linear", e94, '0', '0'], ["eid19", o, 750, 250, "easeInOutCubic", e94, '0', '1'], ["eid25", tp, 1000, 250, "easeInOutCubic", e95, '157px', '177px'], ["eid45", zy, 1500, 250, "easeInOutCubic", e96, '0.5', '1'], ["eid1", zx, 0, 0, "linear", e97, '0.91', '0.91'], ["eid46", lf, 1500, 250, "easeInOutCubic", e96, '18px', '98px'], ["eid2", zy, 0, 0, "linear", e97, '0.91', '0.91'], ["eid44", zx, 1500, 250, "easeInOutCubic", e96, '0.5', '1'], ["eid5", o, 250, 0, "linear", e98, '0', '0'], ["eid35", o, 1250, 250, "easeInOutCubic", e98, '0', '1'], ["eid53", zy, 1750, 250, "easeInOutCubic", e99, '0', '1'], ["eid34", tp, 1250, 250, "easeInOutCubic", e98, '240px', '260px'], ["eid17", zy, 750, 250, "easeInOutCubic", e94, '0', '1'], ["eid6", o, 0, 0, "linear", e96, '0', '0'], ["eid48", o, 1508, 242, "easeInOutCubic", e96, '0', '1'], ["eid9", lf, 0, 750, "easeInOutCubic", e100, '403px', '724px'], ["eid33", zy, 1250, 250, "easeInOutCubic", e98, '0', '1'], ["eid4", o, 250, 0, "linear", e95, '0', '0'], ["eid27", o, 1000, 250, "easeInOutCubic", e95, '0', '1'], ["eid16", tp, 750, 250, "easeInOutCubic", e94, '58px', '91px'], ["eid26", zy, 1000, 250, "easeInOutCubic", e95, '0', '1'], ["eid7", o, 0, 0, "linear", e99, '0', '0'], ["eid54", o, 1750, 250, "easeInOutCubic", e99, '0', '1']]
            }
        }
    };
    AdobeEdge.registerCompositionDefn(compId, symbols, fonts, scripts, resources, opts);
})("EDGE-95933076");
(function ($, Edge, compId) {
    var Composition = Edge.Composition, Symbol = Edge.Symbol;
    Edge.registerEventBinding(compId, function ($) {
//Edge symbol: 'stage'
        (function (symbolName) {
        })("stage");
//Edge symbol end:'stage'

//=========================================================

//Edge symbol: 'rects'
        (function (symbolName) {
        })("rects");
//Edge symbol end:'rects'

//=========================================================

//Edge symbol: 'TEXT_SCAN'
        (function (symbolName) {
        })("TEXT_SCAN");
//Edge symbol end:'TEXT_SCAN'

//=========================================================

//Edge symbol: 'TEXT_ENTER'
        (function (symbolName) {
        })("TEXT_ENTER");
//Edge symbol end:'TEXT_ENTER'

//=========================================================

//Edge symbol: 'TEXT_GETKNOW'
        (function (symbolName) {
        })("TEXT_GETKNOW");
//Edge symbol end:'TEXT_GETKNOW'

//=========================================================

//Edge symbol: 'TEXT_WELCOME'
        (function (symbolName) {
        })("TEXT_WELCOME");
//Edge symbol end:'TEXT_WELCOME'

//=========================================================

//Edge symbol: 'TEXT_URL'
        (function (symbolName) {
        })("TEXT_URL");
//Edge symbol end:'TEXT_URL'

//=========================================================

//Edge symbol: 'banner'
        (function (symbolName) {
        })("banner");
//Edge symbol end:'banner'
    })
})(AdobeEdge.$, AdobeEdge, "EDGE-95933076");